namespace HongHu.Properties
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [CompilerGenerated, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0"), DebuggerNonUserCode]
    internal class Resources
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal Resources()
        {
        }

        internal static Bitmap _����_1
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("_����_1", resourceCulture);
            }
        }

        internal static Bitmap btn_close_down
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_close_down", resourceCulture);
            }
        }

        internal static Bitmap btn_close_highlight
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_close_highlight", resourceCulture);
            }
        }

        internal static Bitmap btn_close_normal
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_close_normal", resourceCulture);
            }
        }

        internal static Bitmap btn_mini_down
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_mini_down", resourceCulture);
            }
        }

        internal static Bitmap btn_mini_highlight
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_mini_highlight", resourceCulture);
            }
        }

        internal static Bitmap btn_mini_normal
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("btn_mini_normal", resourceCulture);
            }
        }

        internal static Bitmap Button
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("Button", resourceCulture);
            }
        }

        internal static Bitmap Button2
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("Button2", resourceCulture);
            }
        }

        internal static Bitmap Button3
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("Button3", resourceCulture);
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get
            {
                return resourceCulture;
            }
            set
            {
                resourceCulture = value;
            }
        }

        internal static Bitmap One_GO
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("One_GO", resourceCulture);
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager temp = new System.Resources.ResourceManager("HongHu.Properties.Resources", typeof(HongHu.Properties.Resources).Assembly);
                    resourceMan = temp;
                }
                return resourceMan;
            }
        }

        internal static Bitmap weelcome
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("weelcome", resourceCulture);
            }
        }

        internal static Bitmap ����_1
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("����_1", resourceCulture);
            }
        }

        internal static Bitmap ����_2_����SQL
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("����_2_����SQL", resourceCulture);
            }
        }

        internal static Bitmap ����_3
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("����_3", resourceCulture);
            }
        }

        internal static Bitmap ��ӭʹ�����ױ�������
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("��ӭʹ�����ױ�������", resourceCulture);
            }
        }

        internal static Bitmap ����
        {
            get
            {
                return (Bitmap)ResourceManager.GetObject("����", resourceCulture);
            }
        }
    }
}

