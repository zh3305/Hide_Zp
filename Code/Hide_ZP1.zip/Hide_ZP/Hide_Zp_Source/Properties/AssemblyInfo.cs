// Assembly HongHu, Version 1.0.0.0

[assembly: System.Reflection.AssemblyVersion("6.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("6.0.0.0")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: System.CLSCompliant(true)]
[assembly: System.Runtime.InteropServices.Guid("21aada3a-97b0-4386-a5f6-c01ba843da16")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("nczy Copyright \x00a9 2010 Nczy. All Rights Reserved")]
[assembly: System.Reflection.AssemblyProduct("HongHu")]
[assembly: System.Reflection.AssemblyCompany("�ϳ��������Ƽ����޹�˾")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("����ͨ���ױ�������")]
[assembly: System.Reflection.AssemblyTitle("����ͨ���ױ�������")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]

